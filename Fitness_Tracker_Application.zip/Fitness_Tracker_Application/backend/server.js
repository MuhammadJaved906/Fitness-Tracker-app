require('dotenv').config()
const express = require('express')
const cors = require('cors')
const mongoose = require('mongoose')
const path = require('path')

const Workout = require('./models/Workout')

const app = express()

const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173'
app.use(
  cors({
    origin: (origin, cb) => {
      // allow no-origin (curl, server-to-server) or known frontend
      if (!origin || origin === FRONTEND_URL) return cb(null, true)
      return cb(null, true) // change this to restrict in production: cb(new Error('Not allowed'), false)
    },
    credentials: true,
  })
)
app.use(express.json())

const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/fitness'
let useDb = false

// simple in-memory fallback store so the API works even without Mongo
const memoryStore = []

async function tryConnect() {
  try {
    await mongoose.connect(MONGO)
    useDb = true
    console.log('Mongo connected')
  } catch (err) {
    useDb = false
    console.warn('Mongo connection failed, using in-memory store. Error:', err.message)
  }
}

tryConnect()

// Data access helpers that abstract DB vs in-memory
async function listWorkouts() {
  if (useDb) return Workout.find().sort({ date: -1 })
  return [...memoryStore].sort((a, b) => new Date(b.date) - new Date(a.date))
}

async function getWorkout(id) {
  if (useDb) return Workout.findById(id)
  return memoryStore.find((w) => w.id === id) || null
}

async function createWorkout(payload) {
  if (useDb) return Workout.create(payload)
  const item = {
    id: Date.now().toString(),
    name: payload.name || '',
    duration: Number(payload.duration) || 0,
    calories: Number(payload.calories) || 0,
    date: payload.date || new Date().toISOString().slice(0, 10),
    progress: Number(payload.progress) || 0,
    createdAt: new Date(),
    updatedAt: new Date(),
  }
  memoryStore.push(item)
  return item
}

async function updateWorkout(id, payload) {
  if (useDb)
    return Workout.findByIdAndUpdate(id, payload, { new: true, runValidators: true })

  const idx = memoryStore.findIndex((w) => w.id === id)
  if (idx === -1) return null
  memoryStore[idx] = { ...memoryStore[idx], ...payload, updatedAt: new Date() }
  return memoryStore[idx]
}

async function deleteWorkout(id) {
  if (useDb) return Workout.findByIdAndDelete(id)
  const idx = memoryStore.findIndex((w) => w.id === id)
  if (idx === -1) return null
  const removed = memoryStore.splice(idx, 1)[0]
  return removed
}

// Basic health check
app.get('/api/health', (req, res) => res.json({ ok: true, db: useDb ? 'mongo' : 'memory' }))

// REST API
app.get('/api/workouts', async (req, res, next) => {
  try {
    const list = await listWorkouts()
    res.json(list)
  } catch (err) {
    next(err)
  }
})

app.get('/api/workouts/:id', async (req, res, next) => {
  try {
    const w = await getWorkout(req.params.id)
    if (!w) return res.status(404).json({ error: 'Not found' })
    res.json(w)
  } catch (err) {
    next(err)
  }
})

app.post('/api/workouts', async (req, res, next) => {
  try {
    if (!req.body || !req.body.name) return res.status(400).json({ error: 'Missing name' })
    const created = await createWorkout(req.body)
    res.status(201).json(created)
  } catch (err) {
    next(err)
  }
})

app.put('/api/workouts/:id', async (req, res, next) => {
  try {
    const updated = await updateWorkout(req.params.id, req.body)
    if (!updated) return res.status(404).json({ error: 'Not found' })
    res.json(updated)
  } catch (err) {
    next(err)
  }
})

app.delete('/api/workouts/:id', async (req, res, next) => {
  try {
    const removed = await deleteWorkout(req.params.id)
    if (!removed) return res.status(404).json({ error: 'Not found' })
    res.json({ success: true })
  } catch (err) {
    next(err)
  }
})

// Serve frontend in production build
if (process.env.NODE_ENV === 'production') {
  const staticPath = path.join(__dirname, '..', 'frontend', 'dist')
  app.use(express.static(staticPath))
  app.get('*', (req, res) => res.sendFile(path.join(staticPath, 'index.html')))
}

// 404
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' })
})

// Error handler
app.use((err, req, res, next) => {
  console.error(err)
  res.status(500).json({ error: err.message || 'Internal Server Error' })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => console.log('Server running on', PORT))
