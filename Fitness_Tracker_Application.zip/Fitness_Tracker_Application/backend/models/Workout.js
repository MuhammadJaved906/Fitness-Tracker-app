const mongoose = require('mongoose')

const WorkoutSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    duration: { type: Number, default: 0 }, // minutes
    calories: { type: Number, default: 0 },
    date: { type: Date, default: () => new Date() },
    progress: { type: Number, default: 0 },
  },
  { timestamps: true }
)

module.exports = mongoose.model('Workout', WorkoutSchema)
