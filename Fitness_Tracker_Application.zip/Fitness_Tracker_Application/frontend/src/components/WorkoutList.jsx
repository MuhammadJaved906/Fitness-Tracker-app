import React from 'react'
import './Workout.css'

function fmtDate(d) {
  if (!d) return ''
  const dt = new Date(d)
  if (isNaN(dt)) return d
  return dt.toLocaleDateString()
}

export default function WorkoutList({ workouts, onEdit, onDelete, onProgress }) {
  if (!workouts || workouts.length === 0) {
    return <p className="muted empty">No workouts yet — add your first session.</p>
  }

  return (
    <div className="workout-list">
      {workouts.map((w) => {
        const percent = Math.min(100, Math.max(0, Number(w.progress) || 0))
        return (
          <article className="workout-card" key={w.id}>
            <div>
              <div className="card-header">
                <h3 className="card-title">{w.name.toUpperCase()}</h3>
                <div className="meta">
                  <span>{w.duration} min</span>
                  <span>{w.calories} kcal</span>
                  <span>{fmtDate(w.date)}</span>
                </div>
              </div>

              {/* additional details could go here */}
            </div>

            <div className="card-actions">
              <button className="btn secondary" onClick={() => onEdit(w.id)}>
                Edit
              </button>
              <button
                className="btn primary"
                onClick={() => onProgress(w.id)}
                title="Increase progress by 10%"
              >
                Update Progress
              </button>
              <button className="btn danger" onClick={() => onDelete(w.id)}>
                Delete
              </button>
            </div>

            <div className="progress-section">
              <div className="progress-label">Progress: {percent}%</div>

              <div
                className="progress-bar"
                role="progressbar"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={percent}
              >
                <div
                  className="progress-fill"
                  style={{ width: `${percent}%` }}
                >
                  <span className="progress-text">{percent}%</span>
                </div>
              </div>
            </div>
          </article>
        )
      })}
    </div>
  )
}
