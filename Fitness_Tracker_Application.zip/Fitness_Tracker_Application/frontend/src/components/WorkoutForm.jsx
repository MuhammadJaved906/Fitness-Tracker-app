import React, { useState, useEffect } from 'react'

export default function WorkoutForm({ onSave, onCancel, initial }) {
  const [name, setName] = useState('')
  const [duration, setDuration] = useState('')
  const [calories, setCalories] = useState('')
  const [date, setDate] = useState('')

  useEffect(() => {
    if (initial) {
      setName(initial.name || '')
      setDuration(initial.duration || '')
      setCalories(initial.calories || '')
      setDate(initial.date || '')
    }
  }, [initial])

  function reset() {
    setName('')
    setDuration('')
    setCalories('')
    setDate('')
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!name.trim()) return alert('Please enter an exercise name')

    const payload = {
      id: initial?.id,
      name: name.trim(),
      duration: Number(duration) || 0,
      calories: Number(calories) || 0,
      date: date || new Date().toISOString().slice(0, 10),
    }

    onSave(payload)
    if (!initial) reset()
  }

  return (
    <form className="workout-form" onSubmit={handleSubmit}>
      
      <div className="row">
        <label>
          <h3>Exercise</h3>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Push ups, Running"
            required
          />
        </label>
        <label>
         <h3>Duration (mins)</h3> 
          <input
            type="number"
            min="0"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            placeholder="30"
          />
        </label>
      </div>

      <div className="row">
        <label>
           <h3>Calories</h3>
          <input
            type="number"
            min="0"
            value={calories}
            onChange={(e) => setCalories(e.target.value)}
            placeholder="200"
          />
        </label>
        <label>
          <h3>Date </h3>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </label>
      </div>

      <div className="form-actions">
        <button type="submit" className="btn primary">
          {initial ? 'Update Workout' : 'Add Workout'}
        </button>
        {initial && (
          <button
            type="button"
            className="btn"
            onClick={() => {
              reset()
              onCancel()
            }}
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  )
}
