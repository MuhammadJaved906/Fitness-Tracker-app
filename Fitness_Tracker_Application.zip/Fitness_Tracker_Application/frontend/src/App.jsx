import React, { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'

import './App.css'
import './components/Workout.css'
import WorkoutForm from './components/WorkoutForm'
import WorkoutList from './components/WorkoutList'

function App() {

  const [workouts, setWorkouts] = useState([])
  const [editing, setEditing] = useState(null)

  useEffect(() => {
    try {
      const raw = localStorage.getItem('workouts')
      if (raw) setWorkouts(JSON.parse(raw))
    } catch (e) {
      console.warn('Failed to load workouts', e)
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem('workouts', JSON.stringify(workouts))
    } catch (e) {
      console.warn('Failed to save workouts', e)
    }
  }, [workouts])

  function handleSave(payload) {
    if (payload.id) {
      setWorkouts((prev) => prev.map((w) => (w.id === payload.id ? { ...w, ...payload } : w)))
      setEditing(null)
    } else {
      const newItem = {
        ...payload,
        id: Date.now().toString(),
        progress: 0,
      }
      setWorkouts((prev) => [newItem, ...prev])
    }
  } 

  function handleEdit(id) {
    const item = workouts.find((w) => w.id === id)
    if (item) setEditing(item)
  }

  function handleCancelEdit() {
    setEditing(null)
  }

  function handleDelete(id) {
    if (!confirm('Delete this workout?')) return
    setWorkouts((prev) => prev.filter((w) => w.id !== id))
  }

  function handleProgress(id) {
    setWorkouts((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w
        const next = Math.min((w.progress || 0) + 10, 100)
        return { ...w, progress: next }
      })
    )
  }

  return (
    <>
     

      <h1>Fitness Tracker</h1>

      <div className="card">
        <WorkoutForm onSave={handleSave} onCancel={handleCancelEdit} initial={editing} />
      </div>

      <div className="card">
        <WorkoutList workouts={workouts} onEdit={handleEdit} onDelete={handleDelete} onProgress={handleProgress} />
      </div>
    
      

      
    </>
  )
}

export default App
